#!/bin/env python3
'''
this simulator_bonsai_bridge.py establishes the bridge between your simulator and the bonsai platform
'''
import bonsai_ai
import numpy as np
import sys, argparse, logging, datetime, time, os, io
import matlab.engine
import random
import matplotlib.pyplot as plt
import math

class BasicSimulator(bonsai_ai.Simulator):
    # KEEP THIS UNCHANGED
    def __init__(self,brain, simulator_name):
        super().__init__(brain, simulator_name)
        logging.debug("__init__")
        # introduce sim_id -- helps identify specific brain training instance,
        # while running multiple instances in parallel
        self.sim_id = -1
        # check or create a folder where all result logs are saved for easy access
        if not os.path.isdir('./ilogs'):
            os.makedirs('./ilogs')
        self.results_logger = setup_logfile(brain, pathname = './ilogs/')
        self.episode_count = 0
        self.simulator_initialize() # defines timestep and max_iterations
        self.started = False


    def episode_start(self, parameters=None):
        """ called at the start of every episode. should
        reset the simulation and return the initial state
        """
        logging.info("reset()")
        # Adding simulator ID for debugging dropouts
        if self.sim_id == -1:
            self.sim_id = self._impl._sim_id  # Implementation detail of SDK2, not guaranteed to be backward compatible
            print(sim.sim_id)
            self.results_logger.info(self.sim_id)
        if self.sim_id != -1:
            logging.info('Simulator ID is: %s', self.sim_id)
        self.iteration = 0
        self.episode_count = self.episode_count + 1
        self.simulator_setup()
        self.state = self.simulator_get_state() #get state from simulator
        self.reward = self.simulator_get_reward()#0
        self.normalized_episode_reward = self.simulator_get_reward()#0 #Accuracy
        self.terminal = self.simulator_get_terminal() #get terminal flag from simulator
        # CHANGE BELOW IF YOU WANT TO LOG MORE OR LESS FREQUENTLY
        #if (self.episode_count==1):
         #   self.print_iteration(initial_iteration=True)
        self.print_iteration()
        if not self.started:# print out a message for our first episode
            self.started = True
            print('started.')
        return self.state

    def simulate(self, action):
        """ run a single step of the simulation.
        if the simulation has reached a terminal state, mark it as such.
        """
        self.iteration += 1
        self.action = action #action is received from the Bonsai BRAIN
        self.simulator_set_action(self.action)
        self.simulator_run()
        self.state = self.simulator_get_state()
        self.terminal = self.simulator_get_terminal()
        self.reward = self.simulator_get_reward()
        self.normalized_episode_reward = (self.normalized_episode_reward + self.reward)/(self.iteration+1) # tracking cumulative reward over an epidode for our simulator side logging
        # CHANGE BELOW IF YOU WANT TO LOG MORE OR LESS FREQUENTLY
        if (self.terminal == True):
            self.print_iteration()

        return (self.state, self.reward, self.terminal)

    #---------------------------------------
    # Below are simulator specific functions that you can change
    #---------------------------------------
    """
    simulator_initialize()
    simulator_setup()
    simulator_set_action() # delta on gains e.g. kp and kd
    simulator_run()
    simulator_get_state() # output that needs to be improved e.g. Y-disp
    simulator_get_terminal() # move to DYNASTY
    simulator_get_reward() # calculate using state and reshape as required
    print_iteration() # log data
    """

    def simulator_initialize(self,predict=False):
        self.max_iterations = 20 # 58 samples in a day

        opts = '-nodesktop -nosplash -minimize'
        self.eng = matlab.engine.start_matlab(opts)
        self.out = io.StringIO()
        self.err = io.StringIO()
        self.eng.workspace['Kp']= 1.0
        self.eng.workspace['Ki']= 1.0

    def simulator_setup(self,predict = False):
        # setting up simulator initial condition
        self.action = {
            'dKp': random.gauss(0.9,0.1),
            'dKi': random.gauss(0.9,0.1)
            #'dKp':0.9,
            #'dKi':0.9
        }
        self.simulator_set_action(self.action)
        self.eng.workspace['dKp']=self.action['dKp']
        self.eng.workspace['dKi']=self.action['dKi']
        self.eng.eval("disablePersistentDMR",nargout=0)
        self.eng.eval("sim('engineclosed.slx')",nargout=0)
        self.eng.eval('exception = MException.last;', nargout=0)
        self.eng.eval('getReport(exception)')
        #plt.plot(self.eng.workspace['time'],self.eng.workspace['drpm'],self.eng.workspace['time'],self.eng.workspace['arpm'])
        #plt.show()
        #plt.savefig('response'+str(self.episode_count)+'.png')


    def simulator_set_action(self, action):

        self.eng.workspace['dKp']=action['dKp']
        self.eng.workspace['dKi']=action['dKi']

    def simulator_run(self):
        # self.eng.eval("warning('off','all')",nargout=0)
        self.eng.eval("sim('engineclosed.slx')",nargout=0)
        self.eng.eval('exception = MException.last;', nargout=0)
        self.eng.eval('getReport(exception)')

    def simulator_get_state(self):
        #Using precomputed normalizing divisors wherever applicable
        maxrpm = np.max(np.transpose(self.eng.workspace['arpm']))/4000
        maxerr = np.max(np.abs(np.transpose(self.eng.workspace['arpm'])-np.transpose(self.eng.workspace['drpm'])))/2000
        errsum = np.sum(np.abs(np.transpose(self.eng.workspace['arpm'])-np.transpose(self.eng.workspace['drpm'])))/3e6
        state = {
        'maxrpm':maxrpm,
        'maxerr':maxerr,
        'errsum':errsum
        }
        print(state)
        return state

    def simulator_get_terminal(self):
        if self.iteration >= self.max_iterations-1:
            terminal = True
        else:
            terminal = False

        # terminal = error_check(self)
        return terminal

    def simulator_get_reward(self):
        # reward function that returns the value for the current iteration relative to the state achieved by the choice of actions
        # if DYNASTYFlag ==0:
        #reward = 1/(1+abs(3000/4000-self.state['maxrpm'])+self.state['errsum'])
#reward = (1/pow((1+abs(self.state['maxerr'])+abs(self.state['errsum'])),5))*1000
        #reward = (1-abs(pow(self.state['maxerr'],0.4)))/abs(self.state['errsum'])
        #reward = (1/pow((1+abs(self.state['maxrpm'])+abs(self.state['errsum'])),5))*1000
        a1 = abs(pow(self.state['maxerr'],0.4))
        #a2 = (3000/4000 - pow(self.state['maxrpm'],1.0))
        a3 = pow(self.state['errsum'],1.0)
        r1 = math.exp(-abs(a1))
        #r2 = math.exp(-abs(a2))
        r3 = pow(math.exp(-abs(a3)), 0.4)
        reward = (r1*r3)

        # else:
         # reward = -0
        print(reward)
        return reward


    def print_iteration(self,initial_iteration=False):
        log_string = "errsum=%4.2f max_rpm=%4.2f maxerr=%4.2f terminal=%5s reward=%6.2f  --- episode=%d norm_reward=%4.2f  iterations=%d" % (
                    self.state['errsum'],
                    self.state['maxrpm'],
                    self.state['maxerr'],
                    str(self.terminal),
                    self.reward,
                    self.episode_count,
                    self.normalized_episode_reward,
                    self.iteration,
                        )
        self.results_logger.info(log_string)

#-----------------------
# end of simulator class
#-----------------------


# TAG LOGGING
def setup_logfile(brain, pathname = './'):
    """setup a logfile to collect results"""

    brainname = brain.name
    predictflag = brain.config.predict #self.brain.config.predict
    if brainname == None: # go past current bug in sdk2 20180206
        brainname = 'brainname'

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # create a file handler
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d-%H_%M_%S')
    if predictflag != False:
        filename = pathname + timestamp + '_' + brainname + '_PREDICT.log'
    else:
        filename = pathname + timestamp + '_' + brainname + '_TRAINING.log'
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s, %(message)s') # create a logging format
    handler.setFormatter(formatter)
    logger.addHandler(handler)  # add the handlers to the logger
    return logger
# MAIN EXECUTION
if __name__ == "__main__":
    config = bonsai_ai.Config(sys.argv) # we get the config and brain info here
    brain = bonsai_ai.Brain(config)
    sim = BasicSimulator(brain,"engctr") # name of simulator declared in inkling need to match the simulator named declared here

    print('starting...')
    while sim.run():
        continue
