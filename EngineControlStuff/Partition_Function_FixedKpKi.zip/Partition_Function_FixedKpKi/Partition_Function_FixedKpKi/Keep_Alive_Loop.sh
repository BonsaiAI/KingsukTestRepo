#!/bin/bash
echo 'keeping simulations running...'

while true
do
   python adaptor.py --train-brain=PartitionFixedKpKi > prober.log
    sleep 60
done
