% Reward Shaping
function plotrewardfunction()
% Calculate max values of states

% maxerr = max(abs(arpm-drpm));
% maxrpm = max(abs(arpm));
maxrpmv = (2000:10:4000)/4000;
maxerrv = (500:10:1500)/2000;
errsum = (0.6:0.001:0.9);



[r,e] = meshgrid(maxrpmv,maxerrv);
surface(r,e,power_reward(r,e));
grid on
view(3)
ylabel('error sum')
xlabel('max errv')
zlabel('Reward')

function reward=power_reward(maxerrv,errsum)
         % reward =500./(1+abs(3000-maxrpmv)+maxerrv);
         reward =(1./((1+abs(maxerrv)+ abs(errsum)).^(5))).*1000;
         %reward = reward*reward;

  return
