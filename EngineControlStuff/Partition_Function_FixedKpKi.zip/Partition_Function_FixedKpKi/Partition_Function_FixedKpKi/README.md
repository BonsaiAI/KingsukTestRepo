# Engine Control Tuning Example
The closed loop engine timing control model is described in https://www.mathworks.com/help/simulink/examples/engine-timing-model-with-closed-loop-control.html

In summary, we are trying to tune a PI controller so that a desired engine RPM can be achieved without much overshoot or error. 


## LOCAL (CLI) GUIDE

### CLI INSTALLATION
1. Install the Bonsai CLI by following our [detailed CLI installation guide](http://docs.bons.ai/guides/cli-guide.html).

### CREATE YOUR BRAIN
1. Setup your BRAIN's local project folder.
       `bonsai create <your_brain>`
2. Run this command to install additional requirements for training your BRAIN.
       `pip install -r requirements.txt`

### HOW TO TRAIN YOUR BRAIN
1. Upload Inkling and simulation files to the Bonsai server with one command.
       `bonsai push`
2. Run this command to start training mode for your BRAIN.
       `bonsai train start`
3. Connect the simulator for training. 
       `python adaptor.py --train-brain=<your_brain>`
4. When training has hit a sufficient accuracy for prediction,stop training your BRAIN.
       `bonsai train stop`

### GET PREDICTIONS
1. Run the simulator using predictions from your BRAIN. You can now see AI tunes the gains of a PI controller for the Engine Model
       `python adaptor.py --predict-brain=<your_brain> --predict-version=latest`

### GENERALIZE
1. Change the model parameters and see whether the tuning still works. Experiment with the STAR (States, Terminal COnditions, Actions and Rewards), until you get acceptable result.

### NOTES ON STAR
S,T,A and R are four areas in the adaptor.py that need to be modified to alter your experimentation. These will improve training or deteriorate depending upon how they are chosen or setup.
In case of Engine Control model, we are trying to control the performance of the PI controller, by tuning P and I gains. What we want to achieve, is low overshoot, fast settling time, and low error. Therefore, we choose the states as below: 
STATE: 
maxrpm -- normalized maximum rpm actually occuring. This is an observed state, in the default STAR. 
maxerr -- normalized difference between actual RPM and desired RPM. By using this as a state, the brain can be instructed to reduce this value. This, in some ways, acts as a overshoot minimizer.
errsum -- This is sum of error (difference between actual and desired RPM) for the entire profile. Minimizing it is important. It acts like reducing integral of error.
ACTIONS:
Since we are tuning PI gains here, there are only two actions, 
dKp - change in the proportional gain Kp
dKi - change in the integral gain Ki

REWARD:
Reward is positive for reducing maximum error (maxerr) and total error (errsum). This can be modified and reshaped to improve performance. A sample default reward function is:
1/(1+abs(3000/4000-self.state['maxrpm'])+self.state['maxerr'])


## Questions about Inkling?
See our [Inkling Guide](http://docs.bons.ai/guides/inkling-guide.html) and [Inkling Reference](http://docs.bons.ai/references/inkling-reference.html) for help.